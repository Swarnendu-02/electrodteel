<?php include_once("includes/header.php"); ?>

<div class="container-fluid inner-banner  position-relative">
    <img src="https://www.kubota.com/index_2020/images/img_area_innovation_pc.jpg" class="career-bk">
    <div class="container position-relative h-100" style="z-index: 1;">
        <div class="row h-100 align-items-center ">
            <div class="col-12">
                <div class="inner-heading">
                    <h2>Facilities</h2>
                </div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">About</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Facilities</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid latest">
    <div class="container">
        <div class="row py-6 align-items-center">
            <div class="col-12 content">
                <p><strong>Facilities</strong><br><br>
                    What started off as a Cast Iron Pipe manufacturing facility 60 years back, has metamorphosed into a true Indian multinational, spanning 5 continents and 110+ countries across the globe. Touching lives with #technologythatcares, our pipelines bring clean drinking water and have been a lifeline to millions. Steadfast on our mission of "Carrying life to people, safe drinking water for all" – over the years, we have been creating industry benchmarks by delivering internationally accredited superior quality Ductile Iron Pipes and Fittings.
                </p>
            </div>

        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative">
    <div class="container position-relative" style="z-index: 1;">
        <div class="row mb-5">
            <div class="col-12 com-fac-grd faci-grd">
                <div class="com-fac-box">
                    <div class="com-fac-lt">
                        <div class="heading">
                            <h2>KHARDAH WORKS (KW)</h2>
                        </div>
                        <div class="content mb-2">
                            <p>Khardah Works (KW) is one of the main two units situated at Khardah near Kolkata, where Electrosteel's Ductile Iron Pipes are manufactured. It has facilities for producing 2.80 Lakh TPA of Ductile Iron pipe right from producing the base metal in Blast Furnace to pipe casting and finishing. It has a Blast Furnace Gas based captive power plant and a 3.6 Lakh TPA sinter plant. It also has facilities for producing Ductile Iron fittings 10,200 TPA and Flange Pipes.</p>
                        </div>
                        <div class="fac-ad content">
                            <p class="mb-0">
                                <span>
                                    <a><i class="fas fa-map-marker mr-2"></i>30, B. T. Road, Khardah, PO-Sukchar, Dist. 24 Parganas (N),<br>West Bengal, India, Pin - 700115</a>
                                    <a href="#"><i class="fas fa-phone mr-2" style="transform: rotate(90deg);"></i>+91 33 7101 4300 / 4450</a>
                                </span>
                                <a href="#"><i class="fas fa-map-marked"></i></a>
                            </p>
                        </div>
                    </div>
                    <div class="com-fac-rt">
                        <img src="images/1607316622khardah_thumb1.jpg" alt="">
                    </div>
                </div>
                <div class="com-fac-box">
                    <div class="com-fac-lt">
                        <div class="heading">
                            <h2>KHARDAH WORKS (KW)</h2>
                        </div>
                        <div class="content mb-2">
                            <p>Khardah Works (KW) is one of the main two units situated at Khardah near Kolkata, where Electrosteel's Ductile Iron Pipes are manufactured. It has facilities for producing 2.80 Lakh TPA of Ductile Iron pipe right from producing the base metal in Blast Furnace to pipe casting and finishing. It has a Blast Furnace Gas based captive power plant and a 3.6 Lakh TPA sinter plant. It also has facilities for producing Ductile Iron fittings 10,200 TPA and Flange Pipes.</p>
                        </div>
                        <div class="fac-ad content">
                            <p class="mb-0">
                                <span>
                                    <a><i class="fas fa-map-marker mr-2"></i>30, B. T. Road, Khardah, PO-Sukchar, Dist. 24 Parganas (N),<br>West Bengal, India, Pin - 700115</a>
                                    <a href="#"><i class="fas fa-phone mr-2" style="transform: rotate(90deg);"></i>+91 33 7101 4300 / 4450</a>
                                </span>
                                <a href="#"><i class="fas fa-map-marked"></i></a>
                            </p>
                        </div>
                    </div>
                    <div class="com-fac-rt">
                        <img src="images/1607316622khardah_thumb1.jpg" alt="">
                    </div>
                </div>
                <div class="com-fac-box">
                    <div class="com-fac-lt">
                        <div class="heading">
                            <h2>KHARDAH WORKS (KW)</h2>
                        </div>
                        <div class="content mb-2">
                            <p>Khardah Works (KW) is one of the main two units situated at Khardah near Kolkata, where Electrosteel's Ductile Iron Pipes are manufactured. It has facilities for producing 2.80 Lakh TPA of Ductile Iron pipe right from producing the base metal in Blast Furnace to pipe casting and finishing. It has a Blast Furnace Gas based captive power plant and a 3.6 Lakh TPA sinter plant. It also has facilities for producing Ductile Iron fittings 10,200 TPA and Flange Pipes.</p>
                        </div>
                        <div class="fac-ad content">
                            <p class="mb-0">
                                <span>
                                    <a><i class="fas fa-map-marker mr-2"></i>30, B. T. Road, Khardah, PO-Sukchar, Dist. 24 Parganas (N),<br>West Bengal, India, Pin - 700115</a>
                                    <a href="#"><i class="fas fa-phone mr-2" style="transform: rotate(90deg);"></i>+91 33 7101 4300 / 4450</a>
                                </span>
                                <a href="#"><i class="fas fa-map-marked"></i></a>
                            </p>
                        </div>
                    </div>
                    <div class="com-fac-rt">
                        <img src="images/1607316622khardah_thumb1.jpg" alt="">
                    </div>
                </div>
                <div class="com-fac-box">
                    <div class="com-fac-lt">
                        <div class="heading">
                            <h2>KHARDAH WORKS (KW)</h2>
                        </div>
                        <div class="content mb-2">
                            <p>Khardah Works (KW) is one of the main two units situated at Khardah near Kolkata, where Electrosteel's Ductile Iron Pipes are manufactured. It has facilities for producing 2.80 Lakh TPA of Ductile Iron pipe right from producing the base metal in Blast Furnace to pipe casting and finishing. It has a Blast Furnace Gas based captive power plant and a 3.6 Lakh TPA sinter plant. It also has facilities for producing Ductile Iron fittings 10,200 TPA and Flange Pipes.</p>
                        </div>
                        <div class="fac-ad content">
                            <p class="mb-0">
                                <span>
                                    <a><i class="fas fa-map-marker mr-2"></i>30, B. T. Road, Khardah, PO-Sukchar, Dist. 24 Parganas (N),<br>West Bengal, India, Pin - 700115</a>
                                    <a href="#"><i class="fas fa-phone mr-2" style="transform: rotate(90deg);"></i>+91 33 7101 4300 / 4450</a>
                                </span>
                                <a href="#"><i class="fas fa-map-marked"></i></a>
                            </p>
                        </div>
                    </div>
                    <div class="com-fac-rt">
                        <img src="images/1607316622khardah_thumb1.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid latest">
    <div class="container">
        <div class="row py-6 align-items-center">
            <div class="col-12 col-md-3 mb-0">
                <h2>Latest<br>@Electrosteel</h2>
            </div>
            <div class="col-12 col-md-7">
                <div class="owl-carousel latest-slide owl-theme">
                    <div class="item">
                        <p><a href="#">September,2023<br><b>Harnessing Water Power</b><br>A unique initiative, undertaken on the eve of World Environment Day, in the presence of an esteemed audi...</a></p>
                    </div>
                    <div class="item">
                        <p><a href="#">September,2023<br><b>Harnessing Water Power</b><br>A unique initiative, undertaken on the eve of World Environment Day, in the presence of an esteemed audi...</a></p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-2 text-md-right">
                <a href="#" class="main-btn">View All</a>
            </div>
        </div>
    </div>
</div>
<?php include_once("includes/footer.php"); ?>
</body>
<script type="text/javascript">
    $('.banner-slide').owlCarousel({
        loop: true,
        margin: 0,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })
    $('.onsocial-owl').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 3
            }
        }
    })
</script>
<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<script>
    $(document).ready(function() {
        $('.faq-clk').click(function() {
            if ($(this).hasClass("active")) {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
            } else {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
                $(this).parent().find(".faqx").slideToggle();
                $(this).parent().find(".faq-clk").toggleClass("active");
            }
        });
    });
</script>

</html>