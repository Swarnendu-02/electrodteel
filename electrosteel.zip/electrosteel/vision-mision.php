<?php include_once("includes/header.php"); ?>

<div class="container-fluid inner-banner  position-relative">
    <img src="https://www.kubota.com/index_2020/images/img_area_innovation_pc.jpg" class="career-bk">
    <div class="container position-relative h-100" style="z-index: 1;">
        <div class="row h-100 align-items-center ">
            <div class="col-12">
                <div class="inner-heading">
                    <h2>Vision Mision</h2>
                </div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">About</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Vision Mision</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid latest">
    <div class="container">
        <div class="row py-6 align-items-center">
            <div class="col-12 content">
                <p><strong>Vision</strong><br><br>
                    To match and supersede world-class standards, in both service and product delivery, by remaining committed to customer satisfaction; to expand horizons and push boundaries, both in our existing and future endeavours, so as to provide continuous growth, profit and prosperity to all our internal and external stakeholders.
                </p>
            </div>

        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative" style="overflow:hidden;">
    <div class="container position-relative">
        <div class="row">
            <h6 class="mb-2">Guiding Principles</h6>
            <div class="content mb-4">
                <p>Our Guiding Principles help us to grow, thrive, prosper and realize our vision.</p>
            </div>
            <ul class="vns-box">
                <li>
                    <span><img src="images/1607156033transparency_ic.png"></span>
                    <div class="vsn-b-rt">
                        <h4>Transparency and Shareholder Value</h4>
                        <div class="content">
                            <p>The Company recognizes its primary obligation to generate a superior return for its shareowners through a prudent strategy, reasonable payouts of dividend and a fair degree of corporate transparency that does not threaten its competitive position in the marketplace.</p>
                        </div>
                    </div>
                </li>
                <li>
                    <span><img src="images/1607156081focus_ic.png"></span>
                    <div class="vsn-b-rt">
                        <h4>Customer Centricity</h4>
                        <div class="content">
                            <p>At Electrosteel, our customers are the central focus around which the Company revolves. We proactively strive to provide them a unique customer experience.</p>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>

<?php include_once("includes/footer.php"); ?>
</body>
<script type="text/javascript">
    $('.banner-slide').owlCarousel({
        loop: true,
        margin: 0,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })
    $('.onsocial-owl').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 3
            }
        }
    })
</script>
<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<script>
    $(document).ready(function() {
        $('.faq-clk').click(function() {
            if ($(this).hasClass("active")) {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
            } else {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
                $(this).parent().find(".faqx").slideToggle();
                $(this).parent().find(".faq-clk").toggleClass("active");
            }
        });
    });
</script>

</html>