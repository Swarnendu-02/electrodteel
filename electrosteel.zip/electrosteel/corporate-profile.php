<?php include_once("includes/header.php"); ?>

<div class="container-fluid inner-banner  position-relative">
    <img src="https://www.kubota.com/index_2020/images/img_area_innovation_pc.jpg" class="career-bk">
    <div class="container position-relative h-100" style="z-index: 1;">
        <div class="row h-100 align-items-center ">
            <div class="col-12">
                <div class="inner-heading">
                    <h2>Corporate Profile</h2>
                </div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">About</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Corporate Profile</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6 latest">
    <div class="container">
        <div class="row  align-items-center">
            <div class="col-12 col-md-3">
                <img src="images/late-ghanshyam-kejriwal.jpg">
            </div>
            <div class="content col-12 col-md-9">
                <i class="fas fa-quote-left" style="    font-size: 61px;position: absolute;/* top: 0; */margin-top: -18px;margin-left: -11px;color: #005b6130;"></i>
                <p class="position-relative mt-3"><i>What is a foundation made of? Not just bricks, mortar or steel. It is made of solid values. That is what our founder Shri Ghanshyam Kejriwal, fondly called “Bada Saab”, taught us.
                        Leading from the front, Bada Saab dared to transform a small unit into a huge conglomerate. His vision and dedication put us on a global platform and made us a true Indian multi-national.</i></p>
                <p class="mt-3">Late Mr. Ghanshyam Kejriwal</p>
            </div>

        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative" style="overflow:hidden;">
    <div class="container position-relative">
        <div class="row">
            <div class="col-12 col-md-5 abt-img">
                <img src="images/DSC_0068.jpg" class="w-100 h-100">
            </div>
            <div class="col-12 col-md-7">
                <div class="heading">
                    <h2>Pioneers in Ductile Iron Pipes In India</h2>
                </div>
                <div class="content">
                    <p class="font-weight-bold">ELECTROSTEEL CASTINGS LIMITED (ECL) has more than six decades of experience in the water infrastructure business. We are the largest manufacturer of Ductile Iron (DI) Pipes in the Indian sub-continent, having a production capacity of 7,00,000 TPA. Back in 1994, we had pioneered the setup of a Ductile Iron Spun Pipe plant in India, using state of the art technology. Our manufacturing activities are spread over 5 different facilities. Now we are the largest producer of Ductile Iron Pipes in India, and the third largest producer of Ductile Iron Spun Pipe in the world.
                    <p>We have a strong brand presence around the globe. Our Pipes and Fittings are exported to more than 110+ countries across 5 continents. We cater to a large customer base spread around the Indian subcontinent, Europe, North and South America, South East Asia, Middle East and Africa. We are the largest exporters of Ductile Iron Pipes in the nation.</p>
                    <p class="text-secondary">Electrosteel has maintained its technological leadership by continual product innovation and technical upgradation. Our widespread marketing network, supported by dedicated professionals help to deliver the product to the doorstep of the customers. Electrosteel has made enough pipes so far, to circle the earth more than 5 times!</p>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include_once("includes/footer.php"); ?>
</body>
<script type="text/javascript">
    $('.banner-slide').owlCarousel({
        loop: true,
        margin: 0,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })
    $('.onsocial-owl').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 3
            }
        }
    })
</script>
<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<script>
    $(document).ready(function() {
        $('.faq-clk').click(function() {
            if ($(this).hasClass("active")) {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
            } else {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
                $(this).parent().find(".faqx").slideToggle();
                $(this).parent().find(".faq-clk").toggleClass("active");
            }
        });
    });
</script>

</html>