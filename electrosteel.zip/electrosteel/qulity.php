<?php include_once("includes/header.php"); ?>

<div class="container-fluid inner-banner  position-relative">
    <img src="https://www.kubota.com/index_2020/images/img_area_innovation_pc.jpg" class="career-bk">
    <div class="container position-relative h-100" style="z-index: 1;">
        <div class="row h-100 align-items-center ">
            <div class="col-12">
                <div class="inner-heading">
                    <h2>Quality</h2>
                </div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Quality</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Quality Certificates</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid latest">
    <div class="container">
        <div class="row py-6 align-items-center">
            <div class="col-12 content">
                <p><strong>Focussed on delivering superior quality products</strong><br><br>
                    Electrosteel Castings offers DI Pipes and DI Fittings that are internationally accredited and globally accepted.<br>
                    <br>
                    The Company continues to maintain the approval of its quality system and products by various agencies including DVGW (Germany), BSI (UK), Middle East, and approval from USA Certifying agencies.
                </p>
            </div>

        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative">
    <div class="container position-relative">
        <div class="row">
            <div class="col-12">
                <h6 class="mb-4">SYSTEM CERTIFICATES</h6>
                <table class="table qulity-table" border="1" cellpadding="0" cellspacing="0">
                    <thead>
                        <tr>
                            <th style="width: 8%;">SL. NO.</th>
                            <th>CERTIFYING BODY</th>
                            <th>ACCREDITATION OF CERTIFYING BODY</th>
                            <th>CERTIFICATE</th>
                            <th>STANDARD</th>
                            <th>LOCATION</th>
                            <th style="width:13%">DOWNLOAD PDF</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-center">1</td>
                            <td>BRITISH STANDARDS INSTITUTION (BSI,UK)</td>
                            <td>IAF, International Accreditation Forum UKAS, UK's National Accreditation Body</td>
                            <td>QUALITY MANAGEMENT SYSTEM</td>
                            <td>ISO9001:2015</td>
                            <td>
                                <select class="table-select">
                                    <option>Select Location</option>
                                    <option>KHARDHA (KW)</option>
                                    <option>SRIKALAHASTHI (SW)</option>
                                </select>
                            </td>
                            <td class="text-center text-primary"><a href="#"><i class="fas fa-download"></i></a></td>
                        </tr>
                    </tbody>
                </table>

            </div>
        </div>
        <div class="row">
            <div class="col-12 mt-4">
                <h6 class="mb-4">PRODUCT CERTIFICATES</h6>
                <table class="table qulity-table" border="1" cellpadding="0" cellspacing="0">
                    <thead>
                        <tr>
                            <th style="width: 8%;">SL. NO.</th>
                            <th>CERTIFYING BODY</th>
                            <th>ACCREDITATION OF CERTIFYING BODY</th>
                            <th>CERTIFICATE</th>
                            <th>STANDARD</th>
                            <th>RANGE</th>
                            <th>SCOPE</th>
                            <th>LOCATION</th>
                            <th style="width:13%">DOWNLOAD PDF</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-center">1</td>
                            <td>DEUTSCHER VEREIN DES GAS- UND WASSERFACHES (DVGW, GERMAN)</td>
                            <td>DAKKS, National accreditation body for the Federal Republic of GERMANY</td>
                            <td>DVGW Cert</td>
                            <td>EN545</td>
                            <td>DN80 - DN1000</td>
                            <td>For drinking water and sewerage application</td>
                            <td>
                                <select class="table-select">
                                    <option>Select Location</option>
                                    <option>KHARDHA (KW)</option>
                                    <option>SRIKALAHASTHI (SW)</option>
                                </select>
                            </td>
                            <td class="text-center text-primary"><a href="#"><i class="fas fa-download"></i></a></td>
                        </tr>
                    </tbody>
                </table>

            </div>
        </div>
        <div class="row">
            <div class="col-12 mt-4">
                <h6 class="mb-4">LICENSE WITH ENDORSEMENT</h6>
                <table class="table qulity-table" border="1" cellpadding="0" cellspacing="0">
                    <thead>
                        <tr>
                            <th style="width: 8%;">SL. NO.</th>
                            <th>LICENSE ISSUED BY</th>
                            <th>PRODUCT</th>
                            <th>PLANT</th>
                            <th>STANDARD</th>
                            <th style="width:13%">DOWNLOAD PDF</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-center">1</td>
                            <td>BIS</td>
                            <td>DI Pipe</td>
                            <td>Khardah</td>
                            <td>IS 8329 : 2000</td>
                            <td class="text-center text-primary"><a href="#"><i class="fas fa-download"></i></a></td>
                        </tr>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>
<?php include_once("includes/footer.php"); ?>
</body>
<script type="text/javascript">
    $('.banner-slide').owlCarousel({
        loop: true,
        margin: 0,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })
    $('.onsocial-owl').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 3
            }
        }
    })
</script>
<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<script>
    $(document).ready(function() {
        $('.faq-clk').click(function() {
            if ($(this).hasClass("active")) {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
            } else {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
                $(this).parent().find(".faqx").slideToggle();
                $(this).parent().find(".faq-clk").toggleClass("active");
            }
        });
    });
</script>

</html>