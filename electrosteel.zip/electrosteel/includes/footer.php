<footer class="container-fluid py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-3">
                <h4><span>ABOUT COMPANY</span></h4>
                <ul>
                    <li>
                        Electrosteel Castings Limited (ECL) products include Ductile Iron Pipes , Ductile Iron Fittings , Ductile Iron Flange Pipes and Restrained Joint Pipes.<br><br>

                        Steadfast on our mission of "Carrying life to people, safe drinking water for all" – over the years, we have been creating industry benchmarks by delivering internationally accredited superior quality Ductile Iron Pipes and Fittings. Our technologically advanced R&D infrastructure and initiatives are geared towards developing some of the best engineered products in the DI Pipes industry.
                    </li>
                    <li>
                        <a href="#" class="rdmr">Read More</a>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-3">
                <h4><span>PRODUCTS</span></h4>
                <ul>
                    <li><a href="#">Ductile Iron Pipes</a></li>
                    <li><a href="#">Ductile Iron Fittings</a></li>
                    <li><a href="#">Ductile Iron Flange Pipes</a></li>
                    <li><a href="#">Restrained Joint Pipes</a></li>
                    <li><a href="#">Cement</a></li>
                    <li><a href="#">Ferro Alloys</a></li>
                </ul>
            </div>
            <div class="col-12 col-md-3">
                <h4><span>REGISTERED OFFICE</span></h4>
                <ul>
                    <li>
                        Rathod Colony<br>
                        PO. Rajgangpur<br>
                        Dist. - Sundergarh<br>
                        Odisha - 770017<br>
                    </li>
                    <li><a href="#">FAQs</a></li>
                    <li>
                        <span>Contact Person:</span>
                        <a href="#">K. K. Jha +91 9771438335</a>
                        <a href="#">Ganeshan +91 8895852693</a>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-3">
                <h4><span>CORPORATE OFFICE</span></h4>
                <ul>
                    <li>
                        Electrosteel Castings Limited<br>
                        G.K. TOWER<br>
                        19, Camac Street<br>
                        Kolkata - 700 017
                    </li>
                    <li><a href="#">Ph. +91-33-22839990/ 71034400</a>
                        <a href="#">Fax +91-33-22894336 (Directors)</a>
                        <a href="#">+91-33-22894337 (Sales)</a>
                        <a href="#">+91-33-2289-4338 (Export)</a>
                        <a href="#">+91-33-22894339 (Finance)</a>
                    </li>

                </ul>
            </div>
        </div>
    </div>
</footer>
<div class="container-fluid py-3 ft-btm">
    <div class="container">
        <div class="row">
            <p><a href="#">Disclaimer</a> | <a href="#">Privacy Policy</a> | <a href="#">Sitemap</a></p>
            <p>© 2023 Electrosteel Castings Limited.</p>
        </div>
    </div>
</div>
<script>
    $('.latest-slide').owlCarousel({
        loop: true,
        margin: 0,
        nav: false,
        autoplay: true,
        autoplayTimeout: 6000,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })
</script>