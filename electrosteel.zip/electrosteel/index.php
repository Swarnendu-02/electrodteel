<?php include_once("includes/header.php"); ?>

<div class="container-fluid banner home-demo p-0 position-relative">
    <div class="owl-carousel banner-slide owl-theme">
        <div class="item">
            <img src="images/BL25STATESRINLVISAKHAPATNAMSTEELPLANT.webp">
            <div class="cover">
                <div class="container position-relative">
                    <a href="#" class="main-btn">Know More</a>
                    <div class="header-content">
                        <div class="line"></div>
                        <h2>Technology<br>that cares</h2>
                        <h4>Carrying life to people – safe drinking water for all</h4>

                    </div>
                </div>
            </div>
        </div>
        <div class="item">
            <img src="images/our-plant-banner-1.webp">
            <div class="cover">
                <div class="container position-relative">
                    <a href="#" class="main-btn">Know More</a>
                    <div class="header-content">
                        <div class="line"></div>
                        <h2>DI Pipes and Fittings<br>latest advancements</h2>
                        <h4>Continuously striving towards product and process improvements</h4>

                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="container-fluid py-6 pt-0 position-relative" style="overflow:hidden;">
    <div class="container position-relative">
        <div class="row">
            <div class="col-12 col-md-6 py-6 pb-0">
                <div class="heading">
                    <h2>About<br>Electrosteel</h2>
                </div>
                <div class="content">
                    <p class="font-weight-bold">Electrosteel Castings Limited (ECL) is a pioneer in the production of Ductile Iron Pipes, Flange Pipe in India, with a strong presence in over 110+ countries across the globe.</p>
                    <p class="text-secondary">What started off as a Cast Iron Pipe manufacturing facility 60 years back, has metamorphosed into a true Indian multinational, spanning 5 continents and 110+ countries across the globe. Touching lives with #technologythatcares, our pipelines bring clean drinking water and have been a lifeline to millions. Steadfast on our mission of "Carrying life to people, safe drinking water for all" – over the years, we have been creating industry benchmarks by delivering internationally accredited superior quality Ductile Iron Pipes and Fittings.</p>
                </div>
                <a href="#" class="main-btn">Know More</a>
                <div class="counter">
                    <div>
                        <h3>25+</h3>
                        <h5>Years Experience</h5>
                    </div>
                    <div>
                        <h3>36</h3>
                        <h5>Industries Served</h5>
                    </div>
                    <div>
                        <h3>105</h3>
                        <h5>Factories Built</h5>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 mt-5 mt-md-0 abt-img">
                <img src="images/DSC_0068.jpg" class="w-100">
                <img src="images/1680179755356.jpg" class="w-100 mt-4">
            </div>
        </div>
    </div>
</div>
<div class="container-fluid  py-6 position-relative" style="overflow:hidden;">
    <div class="container position-relative">
        <div class="row cer-wrap">
            <div class="col-12 col-md-4">
                <div class="cer-inner">
                    <img class="icon-img">
                    <h4><a href="#">Certification</a></h4>
                    <p>The Company continues to maintain the approval of its quality system and products by various agencies...</p>
                    <a class="arrow" href="#"><i class="fas fa-angle-right"></i></a>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="cer-inner">
                    <img class="icon-img">
                    <h4><a href="#">Investor Updates</a></h4>
                    <div class="owl-carousel invester-slide owl-theme">
                        <div class="item">
                            <p><a href="#">Shareholding Pattern as on 24th January 2024</a></p>
                        </div>
                        <div class="item">
                            <p><a href="#">Financial Results for the quarter ended 31st December, 2023</a></p>
                        </div>
                        <div class="item">
                            <p><a href="#">Annual Report 2022-23</a></p>
                        </div>
                    </div>
                    <!-- <a class="arrow" href="#"><i class="fas fa-angle-right"></i></a> -->
                </div>

            </div>
            <div class="col-12 col-md-4">
                <div class="cer-inner">
                    <img class="icon-img">
                    <h4><a href="#">Contact</a></h4>
                    <p><a href="#"><i class="fas fa-phone mr-3" style="transform: rotate(90deg);"></i>+91-33-22894337 (Sales)</a><br>
                        <a href="#"><i class="fas fa-phone mr-3" style="transform: rotate(90deg);"></i>+91-33-2289-4338 (Export)</a><br>
                        <a href="#"><i class="fas fa-phone mr-3" style="transform: rotate(90deg);"></i>+91-33-22894339 (Finance)</a><br>
                    </p>
                    <a class="arrow" href="#"><i class="fas fa-angle-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid latest">
    <div class="container">
        <div class="row py-6 align-items-center">
            <div class="col-12 col-md-3 mb-0">
                <h2>Latest<br>@Electrosteel</h2>
            </div>
            <div class="col-12 col-md-7">
                <div class="owl-carousel latest-slide owl-theme">
                    <div class="item">
                        <p><a href="#">September,2023<br><b>Harnessing Water Power</b><br>A unique initiative, undertaken on the eve of World Environment Day, in the presence of an esteemed audi...</a></p>
                    </div>
                    <div class="item">
                        <p><a href="#">September,2023<br><b>Harnessing Water Power</b><br>A unique initiative, undertaken on the eve of World Environment Day, in the presence of an esteemed audi...</a></p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-2 text-md-right">
                <a href="#" class="main-btn">View All</a>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid bk-pri py-6">
    <div class="container">
        <div class="row mb-4">
            <div class="col-12 heading">
                <h2 class="text-center text-white">Products</h2>
            </div>
            <div class="col-12 prd-wrap">
                <div class="prd-box">
                    <img src="images/1608792010ductile-iron-pipes-overview_banner.jpg">
                    <h4 class="text-white">Ductile Iron Pipe</h4>
                    <p class="text-white">Ductile Iron is an improved variety of Cast Iron invented in 1949. It is also known as Spheroidal Graphite Iron or Nodular Cast...</p>
                    <a href="#"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                </div>
                <div class="prd-box">
                    <img src="images/1608794273ductile-iron-fittings-big.jpg">
                    <h4 class="text-white">Ductile Iron Fittings</h4>
                    <p class="text-white">Electrosteel Castings Limited is one of the premier manufactures of Ductile Iron Fittings in India. The fittings are manufactured in...</p>
                    <a href="#"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                </div>
                <div class="prd-box">
                    <img src="images/1608375019others_products_thumb.jpg">
                    <h4 class="text-white">Cast Iron Pipes</h4>
                    <p class="text-white">Electrosteel has a cast iron spun pipe manufacturing unit at Elavur, near Chennai in Tamil Nadu, which are manufactured as...</p>
                    <a href="#"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid position-relative">
    <img src="images/corporate-social-responsibility.webp" class="csrimg">
    <div class="container ">
        <div class="row">
            <div class="col-12 col-md-6 offset-md-6 py-6 pl-md-5">
                <div class="heading">
                    <h2>CSR Overview</h2>
                </div>
                <div class="content">
                    <p class="font-weight-bold">An enterprise with multi-locational state of the art manufacturing facilities</p>
                    <p class="text-secondary">We engage regularly with our stakeholders to understand their needs and concerns and look to strengthen their communities with our endeavors. The guiding principle behind our CSR activities is to maximize the impact it has on the quality of lives of the community.</p>
                </div>
                <ul class="csr-ul">
                    <li>To develop an equitable society by helping to create and foster livelihood opportunities for the underprivileged and marginalized communities.</li>
                    <li>To develop an equitable society by helping to create and foster livelihood opportunities for the underprivileged and marginalized communities.</li>
                    <li>To develop an equitable society by helping to create and foster livelihood opportunities for the underprivileged and marginalized communities.</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6">
    <div class="container">
        <div class="row">
            <div class="col-12 prd-wrap facility-wrap">
                <div>
                    <div class="heading">
                        <h2>Facilities</h2>
                    </div>
                    <div class="content">
                        <p class="font-weight-bold">Corporate Social Responsibility has a long tradition in Electrosteel. For the last many decades, we have created a niche for ourselves, not just as a technology and innovation pioneer, but also as a Company that lives its mantra of "technology that cares".</p>
                        <p class="text-secondary">We engage regularly with our stakeholders to understand their needs and concerns and look to strengthen their communities with our endeavors. The guiding principle behind our CSR activities is to maximize the impact it has on the quality of lives of the community.</p>
                    </div>
                    <a href="#" class="main-btn">Know More</a>
                </div>
                <div class="prd-box">
                    <img src="images/1607316622khardah_thumb1.jpg" alt="">
                    <h4>KHARDAH WORKS (KW)</h4>
                    <p>Khardah Works (KW) is one of the main two units situated at Khardah near Kolkata, where Electrosteel's Ductile Iron Pipes are manufactured. It has facilities for producing...</p>
                    <a href="#"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                </div>
                <div class="prd-box">
                    <img src="images/srikalakashiimg.jpg" alt="">
                    <h4>SRIKALAHASTHI WORKS (SW)</h4>
                    <p>Srikalahasthi Works (SW) of Electrosteel has a state-of-the-art manufacturing facility in Rachagunneri Village on Tirupati-Srikalahasthi Road, Srikalahasthi Mandal, Tirupati District of...</p>
                    <a href="#"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                </div>
                <div class="prd-box">
                    <img src="images/1607321620haldia_thumb1.jpg" alt="">
                    <h4>HALDIA WORKS (HW)</h4>
                    <p>Haldia Works (HW) is located in the Industrial town of Haldia in West Bengal. It has a 3,24,000 TPA Coke Oven Plant and 2 X 100 TPD Sponge Iron unit. Here, we also have a DI fittings and...</p>
                    <a href="#"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                </div>
                <div class="prd-box">
                    <img src="images/1607321668bansberia_thumb-new.jpg" alt="">
                    <h4>BANSBERIA WORKS (BW)</h4>
                    <p>Bansberia Works (BW) , spread over 22 acres of land, is our ultra-modern DI Pipe coating and finishing plant. It is located at Bansberia near Kolkata. Our wide range of linings and...</p>
                    <a href="#"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                </div>
                <div class="prd-box">
                    <img src="images/1607529145elavur_thumb.jpg" alt="">
                    <h4>ELAVUR WORKS (EW)</h4>
                    <p>Elavur Works (EW) is located near Chennai in Tamil Nadu, Electrosteel has a 36,000 TPA Cast Iron Spun Pipe manufacturing facility. It is the biggest Cast Iron Pipe manufacturing...</p>
                    <a href="#"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6 career-wrap position-relative">
    <div class="container position-relative" style="z-index: 1;">
        <div class="row mb-5">
            <div class="col-12 col-md-9">
                <img src="images/map.png" class="w-100">
            </div>
            <div class="col-12 col-md-3">
                <div class="heading">
                    <h2 class="text-white">Globally<br>Presence</h2>
                </div>
                <ul class="csr-ul presen-ul">
                    <li class="text-white">INDIA</li>
                    <li class="text-white">NEPAL</li>
                    <li class="text-white">BHUTAN</li>
                    <li class="text-white">BANGLADESH</li>
                    <li class="text-white">CHINA</li>
                    <li class="text-white">SINGAPORE</li>
                    <li class="text-white">MALAYSIA</li>
                </ul>
            </div>

        </div>
    </div>
</div>
<div class="container-fluid career">
    <div class="container">
        <div class="row">
            <div class="col-12 start-prjct">
                <div>
                    <h2>Career</h2>
                    <p>To start, use form to tell us about you and the project</p>
                </div>
                <a href="#" class="main-btn">Let’s connect</a>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 heading">
                <h2 class="text-center">Certifying Bodies</h2>
            </div>
            <div class="col-12 prd-wrap crfat-wrap mb-5">
                <div>
                    <img src="images/1607152450acs_logo.jpg">
                </div>
                <div>
                    <img src="images/cb2.jpg">
                </div>
                <div>
                    <img src="images/cb3.jpg">
                </div>
                <div>
                    <img src="images/cb4.jpg">
                </div>
                <div>
                    <img src="images/cb5.jpg">
                </div>
                <div>
                    <img src="images/cb6.jpg">
                </div>
                <div>
                    <img src="images/cb7.jpg">
                </div>
                <div>
                    <img src="images/cb8.jpg">
                </div>

            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6 pt-0 position-relative">
    <div class="container">
        <div class="row">
            <div class="col-12 heading">
                <h2 class="text-center">On Social</h2>
            </div>
            <div class="col-12">
                <div class="owl-carousel owl-theme onsocial-owl">
                    <div class="item">
                        <div class="prd-box">
                            <img src="images/431165699_727431302855091_1703333604815571097_n.jpg">
                            <h4>27th Match, 2024</h4>
                            <p>#BREAKINGNEWS #ElectrosteelCastingsLtd was felicitated at the World HRD Congress for its commitment ..</p>
                            <a href="#"><i class="fas fa-long-arrow-alt-right"></i></span></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="prd-box">
                            <img src="images/8883600158152129148.jpg">
                            <h4>29th Match, 2024</h4>
                            <p>Tee off with #ElectrosteelCastingsLtd! The Electrosteel Tolly Putting Championship 2024 saw an in ..</p>
                            <a href="#"><i class="fas fa-long-arrow-alt-right"></i></span></a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="prd-box">
                            <img src="images/431562788_734016148863273_8390132269509555193_n.jpg">
                            <h4>30th Match, 2024</h4>
                            <p>#ElectrosteelCastingsLtd participated in the 3rd Roorkee Water Conclave, 'Responsible Water Manageme ..</p>
                            <a href="#"><i class="fas fa-long-arrow-alt-right"></i></span></a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php include_once("includes/footer.php"); ?>
</body>
<script type="text/javascript">
    $('.banner-slide').owlCarousel({
        loop: true,
        margin: 0,
        nav: true,
        autoplay: true,
        autoplayTimeout: 6000,
        animateOut: "slideOutDown",
        animateIn: "slideInDown",
        items: 1,
        dots: false,
        navText: ["<span aria-label='Previous''><i class='fas fa-angle-left'></i></span>", "<span aria-label='Next'><i class='fas fa-angle-right'></i></span>"],
    })
    $('.onsocial-owl').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 3
            }
        }
    })
    $('.invester-slide').owlCarousel({
        loop: true,
        margin: 0,
        nav: false,
        autoplay: true,
        autoplayTimeout: 6000,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })
    
</script>
<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<script>
    $(document).ready(function() {
        $('.faq-clk').click(function() {
            if ($(this).hasClass("active")) {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
            } else {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
                $(this).parent().find(".faqx").slideToggle();
                $(this).parent().find(".faq-clk").toggleClass("active");
            }
        });
    });
</script>

</html>