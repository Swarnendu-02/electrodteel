<?php include_once("includes/header.php"); ?>

<div class="container-fluid inner-banner  position-relative">
    <img src="https://www.kubota.com/index_2020/images/img_area_innovation_pc.jpg" class="career-bk">
    <div class="container position-relative h-100" style="z-index: 1;">
        <div class="row h-100 align-items-center ">
            <div class="col-12">
                <div class="inner-heading">
                    <h2>Ductile Iron Pipes</h2>
                </div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Products</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Ductile Iron Pipes</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid latest">
    <div class="container">
        <div class="row py-6 align-items-center">
            <div class="col-12 content">
                <p><strong>Ductile Iron pipes made by Electrosteel Castings Ltd. conform to the following Indian and International standards:</strong><br><br>
                    IS 8329 / IS 9523, ISO 2531 / ISO 7186, EN 545 / EN 598, AWWA - C 151
                </p>
                <img src="images/1546982_PUSH_ON_JOINT_30.08.2022.jpg" class="w-100 mt-4">
            </div>

        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative">
    <div class="container position-relative">
        <div class="row">
            <div class="col-12">
                <h6 class="mb-4">BASIC DIMENSION OF PIPES-PRESSURE CLASS ( As per ISO:2531 and EN:545) and THICKNESS CLASS (As per IS:8329)</h6>
                <table class="table qulity-table" border="1" cellpadding="0" cellspacing="0">
                    <tbody>
                        <tr>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th colspan="2">PRESSURE CLASS</th>
                            <th colspan="2">THICKNESS CLASS</th>
                        </tr>
                        <tr>
                            <th>Nominal Dia.<br>
                                DN </th>
                            <th>External Dia.<br>
                                (DE) </th>
                            <th>Tol. on<br>
                                DE </th>
                            <th>Preferred<br>
                                'C' class </th>
                            <th>C class <br>
                                Nom Thickness </th>
                            <th>Nominal Thickness of K9 </th>
                            <th>Nominal Thickness of K7 </th>
                        </tr>
                        <tr>
                            <th> (mm) </th>
                            <th> (mm) </th>
                            <th> (mm) </th>
                            <th> </th>
                            <th> (mm) </th>
                            <th> (mm) </th>
                            <th> (mm) </th>
                        </tr>
                        <tr>
                            <td>80</td>
                            <td>98</td>
                            <td>+1/-2.7</td>
                            <td>C40</td>
                            <td>4.4</td>
                            <td>6</td>
                            <td>5</td>
                        </tr>
                        <tr>
                            <td>100</td>
                            <td>118</td>
                            <td>+1/-2.8</td>
                            <td>C40</td>
                            <td>4.4</td>
                            <td>6</td>
                            <td>5</td>
                        </tr>
                        <tr>
                            <td>150</td>
                            <td>170</td>
                            <td>+1/-2.9</td>
                            <td>C40</td>
                            <td>4.5</td>
                            <td>6</td>
                            <td>5</td>
                        </tr>
                        <tr>
                            <td>200</td>
                            <td>222</td>
                            <td>+1/-3.0</td>
                            <td>C40</td>
                            <td>4.7</td>
                            <td>6.3</td>
                            <td>5</td>
                        </tr>
                        <tr>
                            <td>250</td>
                            <td>274</td>
                            <td>+1/-3.1</td>
                            <td>C40</td>
                            <td>5.5</td>
                            <td>6.8</td>
                            <td>5.3</td>
                        </tr>
                        <tr>
                            <td>300</td>
                            <td>326</td>
                            <td>+1/-3.3</td>
                            <td>C40</td>
                            <td>6.2</td>
                            <td>7.2</td>
                            <td>5.6</td>
                        </tr>
                        <tr>
                            <td>350</td>
                            <td>378</td>
                            <td>+1/-3.4</td>
                            <td>C30</td>
                            <td>6.3</td>
                            <td>7.7</td>
                            <td>6.0</td>
                        </tr>
                        <tr>
                            <td>400</td>
                            <td>429</td>
                            <td>+1/-3.5</td>
                            <td>C30</td>
                            <td>6.5</td>
                            <td>8.1</td>
                            <td>6.3</td>
                        </tr>
                        <tr>
                            <td>450</td>
                            <td>480</td>
                            <td>+1/-3.6</td>
                            <td>C30</td>
                            <td>6.9</td>
                            <td>8.6</td>
                            <td>6.6</td>
                        </tr>
                        <tr>
                            <td>500</td>
                            <td>532</td>
                            <td>+1/-3.8</td>
                            <td>C30</td>
                            <td>7.5</td>
                            <td>9.0</td>
                            <td>7.0</td>
                        </tr>
                        <tr>
                            <td>600</td>
                            <td>635</td>
                            <td>+1/-4 .0</td>
                            <td>C30</td>
                            <td>8.7</td>
                            <td>9.9</td>
                            <td>7.7</td>
                        </tr>
                        <tr>
                            <td>700</td>
                            <td>738</td>
                            <td>+1/4.3</td>
                            <td>C25</td>
                            <td>8.8</td>
                            <td>10.8</td>
                            <td>9.0</td>
                        </tr>
                        <tr>
                            <td>800</td>
                            <td>842</td>
                            <td>+1/4.5</td>
                            <td>C25</td>
                            <td>9.6</td>
                            <td>11.7</td>
                            <td>10.4</td>
                        </tr>
                        <tr>
                            <td>900</td>
                            <td>945</td>
                            <td>+1/-4.8</td>
                            <td>C25</td>
                            <td>10.6</td>
                            <td>12.6</td>
                            <td>11.2</td>
                        </tr>
                        <tr>
                            <td>1000</td>
                            <td>1048</td>
                            <td>+1/-5.0</td>
                            <td>C25</td>
                            <td>11.6</td>
                            <td>13.5</td>
                            <td>12.0</td>
                        </tr>
                        <tr>
                            <td>1100</td>
                            <td>1152</td>
                            <td>+1/-6.0</td>
                            <td>C25</td>
                            <td>12.6</td>
                            <td>14.4</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>1200</td>
                            <td>1255</td>
                            <td>+1/-6.2</td>
                            <td>C25</td>
                            <td>13.6</td>
                            <td>15.3</td>
                            <td></td>
                        </tr>

                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative">
    <div class="container ">
        <div class="row">
            <div class="col-12 col-md-6 abt-img">
                <img src="images/DSC_0068.jpg" class="w-100 h-100">
            </div>
            <div class="col-12 col-md-6">
                <div class="heading">
                    <h2>Applications</h2>
                </div>
                <ul class="csr-ul">
                    <li>Raw and clear water transmission (pumping and gravity main)</li>
                    <li>Distribution network of potable water</li>
                    <li>Water supply for industrial/process plant application</li>
                    <li>Ash-slurry handling & disposal system</li>
                    <li>Fire-fighting systems - on-shore and off-shore</li>
                    <li>Desalination plants</li>
                    <li>Sewerage and waste water force main</li>
                    <li>Gravity sewerage collection and disposal system</li>
                    <li>Storm water drainage piping</li>
                    <li>Effluent disposal system for domestic and industrial application</li>
                    <li>Recycling system</li>
                    <li>Piping work inside water and sewage treatment plants</li>
                    <li>Vertical connection to utilities and reservoirs</li>
                    <li>Piling for ground stabilization</li>
                    <li>Protective piping under major carriage-ways</li>
                    <li>Trenchless applications</li>
                </ul>
            </div>

        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative bk-pri" style="overflow:hidden;">
    <div class="container position-relative">
        <div class="row">
            <div class="col-12 heading">
                <h2 class="text-center text-white">Jointing Systems</h2>
            </div>
            <div class="col-12 content">
                <p class="text-center text-white">Electrosteel Ductile Iron Pipes and Fittings are available with following types of Jointing Systems –</p>
            </div>
            <ul class="join-wrap col-12 col-md-8 offset-md-2">
                <li>
                    <h6 class="join-clk">Push-on Joint<i class="fas fa-chevron-down"></i></h6>
                    <div class="joinx">
                        <p>Socket and Spigot Flexible Joints are assembled with synthetic rubber gaskets of special shape - the gasket has a hard ‘Heel' and a soft 'Bulb'.</p>
                        <a href="#" class="rd-more"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                        <a href="#" class="dwn"><i class="fas fa-download"></i></a>
                    </div>
                </li>
                <li>
                    <h6 class="join-clk">Push-on Joint<i class="fas fa-chevron-down"></i></h6>
                    <div class="joinx">
                        <p>Socket and Spigot Flexible Joints are assembled with synthetic rubber gaskets of special shape - the gasket has a hard ‘Heel' and a soft 'Bulb'.</p>
                        <a href="#" class="rd-more"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                        <a href="#" class="dwn"><i class="fas fa-download"></i></a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative" style="overflow:hidden;">
    <div class="container position-relative">
        <div class="row">
            <div class="col-12 col-md-6 heading">
                <h2>Protection Systems</h2>
            </div>
            <div class="col-12 col-md-6">
                <div class="tab text-md-right">
                    <button class="tablinks active" onclick="openCity(event, 'Cocacola')">Internal</button>
                    <button class="tablinks" onclick="openCity(event, 'Thumup')">Exnternal</button>
                </div>
            </div>
            <div class="col-12 mt-2 d-none d-md-block">
                <div id="Cocacola" class="tabcontent " style="display: block;">
                    <ul class="pro-sys">
                        <li>
                            <div>
                                <h6>Cement Mortar Lining</h6>
                                <p>Normally, all pipes are supplied with centrifugally applied internal Cement Mortar Lining.
                                    <br><b class="mr-2">Guiding standards:</b>ISO 4179 BS EN 545 IS 8329
                                </p>
                                <a href="#" class="rd-more"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                            </div>
                            <a href="#" class="dwn"><i class="fas fa-download"></i></a>
                        </li>
                        <li>
                            <div>
                                <h6>Cement Mortar Lining</h6>
                                <p>Normally, all pipes are supplied with centrifugally applied internal Cement Mortar Lining.
                                    <br><b class="mr-2">Guiding standards:</b>ISO 4179 BS EN 545 IS 8329
                                </p>
                                <a href="#" class="rd-more"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                            </div>
                            <a href="#" class="dwn"><i class="fas fa-download"></i></a>
                        </li>
                    </ul>
                </div>
                <div id="Thumup" class="tabcontent " >
                    <ul class="pro-sys">
                        <li>
                            <div>
                                <h6>Cement Mortar Lining</h6>
                                <p>Normally, all pipes are supplied with centrifugally applied internal Cement Mortar Lining.
                                    <br><b class="mr-2">Guiding standards:</b>ISO 4179 BS EN 545 IS 8329
                                </p>
                                <a href="#" class="rd-more"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                            </div>
                            <a href="#" class="dwn"><i class="fas fa-download"></i></a>
                        </li>
                        <li>
                            <div>
                                <h6>Cement Mortar Lining</h6>
                                <p>Normally, all pipes are supplied with centrifugally applied internal Cement Mortar Lining.
                                    <br><b class="mr-2">Guiding standards:</b>ISO 4179 BS EN 545 IS 8329
                                </p>
                                <a href="#" class="rd-more"> Read More<span><i class="fas fa-angle-right"></i></span></a>
                            </div>
                            <a href="#" class="dwn"><i class="fas fa-download"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include_once("includes/footer.php"); ?>
</body>
<script type="text/javascript">
    $('.banner-slide').owlCarousel({
        loop: true,
        margin: 0,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })
    $('.onsocial-owl').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 3
            }
        }
    })
</script>
<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<script>
    $(document).ready(function() {
        $('.join-clk').click(function() {
            if ($(this).hasClass("active")) {
                $(".joinx").slideUp();
                $(".join-clk").removeClass("active");
            } else {
                $(".joinx").slideUp();
                $(".join-clk").removeClass("active");
                $(this).parent().find(".joinx").slideToggle();
                $(this).parent().find(".join-clk").toggleClass("active");
            }
        });
    });
</script>

</html>