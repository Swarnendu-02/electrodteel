<?php include_once("includes/header.php"); ?>

<div class="container-fluid inner-banner  position-relative">
    <img src="https://www.kubota.com/index_2020/images/img_area_innovation_pc.jpg" class="career-bk">
    <div class="container position-relative h-100" style="z-index: 1;">
        <div class="row h-100 align-items-center ">
            <div class="col-12">
                <div class="inner-heading">
                    <h2>Company Profile</h2>
                </div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">About</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Company Profile</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid latest">
    <div class="container">
        <div class="row py-6 align-items-center">
            <div class="col-12 content">
                <p><strong>Growing from strength to strength over half a century</strong><br><br>
                    What started off as a Cast Iron Pipe manufacturing facility 60 years back, has metamorphosed into a true Indian multinational, spanning 5 continents and 110+ countries across the globe. Touching lives with #technologythatcares, our pipelines bring clean drinking water and have been a lifeline to millions. Steadfast on our mission of "Carrying life to people, safe drinking water for all" – over the years, we have been creating industry benchmarks by delivering internationally accredited superior quality Ductile Iron Pipes and Fittings.
                </p>
            </div>

        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative" style="overflow:hidden;">
    <div class="container position-relative">
        <div class="row">
            <div class="col-12 col-md-12 abt-img">
                <img src="images/DSC_0068.jpg" class="w-100">
            </div>
            <div class="col-12 col-md-12 mt-5 text-center">
                <div class="heading">
                    <h2 class="text-center">Technology and Innovation</h2>
                </div>
                <div class="content">
                    <p class="text-center">Electrosteel Castings Limited has five technologically advanced manufacturing units located in Khardah, Bansberia and Haldia (in West Bengal) and Elavur (in Tamil Nadu) and Srikalahasthi (in Andhrapradesh).</p>
                </div>
                <a href="#" class="main-btn">Know More</a>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6 career-wrap position-relative">
    <div class="container position-relative" style="z-index: 1;">
        <div class="row mb-5">
            <div class="col-12 com-fac-grd">
                <div class="com-fac-box">
                    <div class="com-fac-lt">
                        <h4>KHARDAH WORKS (KW)</h4>
                        <ul class="csr-ul">
                            <li>Company's first manufacturing facility</li>
                            <li>DI Pipes & DI Flange pipes</li>
                            <li>Pig Iron</li>
                            <li>Captive Power Plant</li>
                            <li>Sinter Plant</li>
                        </ul>
                    </div>
                    <div class="com-fac-rt">
                        <img src="images/1607316622khardah_thumb1.jpg" alt="">
                    </div>
                </div>
                <div class="com-fac-box">
                    <div class="com-fac-lt">
                        <h4>KHARDAH WORKS (KW)</h4>
                        <ul class="csr-ul">
                            <li>Company's first manufacturing facility</li>
                            <li>DI Pipes & DI Flange pipes</li>
                            <li>Pig Iron</li>
                            <li>Captive Power Plant</li>
                            <li>Sinter Plant</li>
                        </ul>
                    </div>
                    <div class="com-fac-rt">
                        <img src="images/1607316622khardah_thumb1.jpg" alt="">
                    </div>
                </div>
                <div class="com-fac-box">
                    <div class="com-fac-lt">
                        <h4>KHARDAH WORKS (KW)</h4>
                        <ul class="csr-ul">
                            <li>Company's first manufacturing facility</li>
                            <li>DI Pipes & DI Flange pipes</li>
                            <li>Pig Iron</li>
                            <li>Captive Power Plant</li>
                            <li>Sinter Plant</li>
                        </ul>
                    </div>
                    <div class="com-fac-rt">
                        <img src="images/1607316622khardah_thumb1.jpg" alt="">
                    </div>
                </div>
                <div class="com-fac-box">
                    <div class="com-fac-lt">
                        <h4>KHARDAH WORKS (KW)</h4>
                        <ul class="csr-ul">
                            <li>Company's first manufacturing facility</li>
                            <li>DI Pipes & DI Flange pipes</li>
                            <li>Pig Iron</li>
                            <li>Captive Power Plant</li>
                            <li>Sinter Plant</li>
                        </ul>
                    </div>
                    <div class="com-fac-rt">
                        <img src="images/1607316622khardah_thumb1.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid career">
    <div class="container">
        <div class="row">
            <div class="col-12 start-prjct">
                <div>
                    <h2>Career</h2>
                    <p>To start, use form to tell us about you and the project</p>
                </div>
                <a href="#" class="main-btn">Let’s connect</a>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-6 position-relative" style="overflow:hidden;">
    <div class="container position-relative">
        <div class="row align-items-center">
            <div class="col-12 col-md-7">
                <div class="heading">
                    <h2>Our People - Our Biggest Asset</h2>
                </div>
                <div class="content">
                    <p>Electrosteel Castings is driven by a team of committed professionals equipped with the right expertise and experience to understand and evaluate the customer's priorities, uphold good governance, function as per aligned strategies and ensure continuous all round development of the organisation.</p>
                </div>
                <a href="#" class="main-btn">Know More</a>
            </div>
            <div class="col-12 col-md-5 abt-img">
                <img src="images/1608362210_people_thumb-new.jpg" class="w-100">
            </div>
        </div>
    </div>
</div>
<?php include_once("includes/footer.php"); ?>
</body>
<script type="text/javascript">
    $('.banner-slide').owlCarousel({
        loop: true,
        margin: 0,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })
    $('.onsocial-owl').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 3
            }
        }
    })
</script>
<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<script>
    $(document).ready(function() {
        $('.faq-clk').click(function() {
            if ($(this).hasClass("active")) {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
            } else {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
                $(this).parent().find(".faqx").slideToggle();
                $(this).parent().find(".faq-clk").toggleClass("active");
            }
        });
    });
</script>

</html>